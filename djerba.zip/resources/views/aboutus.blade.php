@extends('layouts.app')

@section('title')
- About US
@endsection

@section('AboutusisActive')
    class="active"
@endsection

@section('content')
<div class="container-fluid">
   <img src="/assets/images/palette.jpg" alt="Palette Image" class="img-responsive center-block" style="width: 100%; display: block;"/>
</div>

<style>
    body{
    background-color: #45362E;
}
</style>
@endsection