        
<style type="text/css">
    #tfheader{
        background-color:#B8A773;
    }
    #tfnewsearch{
        float:right;
        padding:11px;
    }
    .tftextinput2{
        margin: 0;
        padding: 5px 15px;
        /*font-family: Arial, Helvetica, sans-serif;*/
        font-size:13.94px;
        color:#523D1F;
        border:0px solid #000000; border-right:0px;
        border-top-left-radius: 5px 5px;
        border-bottom-left-radius: 5px 5px;
    }
  
    .tfbutton2 {
        margin: 0;
        padding: 4px 7px;
        /*font-family: Arial, Helvetica, sans-serif;*/
        font-size:14px;
        font-weight:bold;
        outline: none;
        cursor: pointer;
        text-align: center;
        text-decoration: none;
        color: #000000;
        border: solid 1px #FFFFFF; border-right:0px;
        background: #FFFFFF;
        border-top-right-radius: 5px 5px;
        border-bottom-right-radius: 5px 5px;
    }
    .tfbutton2:hover {
        text-decoration: none;
        background: #FFFFFF;
    }
    /* Fixes submit button height problem in Firefox */
    .tfbutton2::-moz-focus-inner {
      border: 0;
    }
    .tfclear{
        clear:both;
    }
</style>
                                
                   