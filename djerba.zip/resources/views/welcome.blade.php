@extends('layouts.app')

@section('content')
<body>
  <div class="row">&nbsp;</div>
  <div class="row">&nbsp;</div>
  <div class="jumbotron text-center">
  <div class="container">
    <h1>DJERBA</h1> 
    <h4 style=" color: #87766C;">Your portal for art</h4> 
  </div>
  </div>
</body>

<style>
    body{
    background-color: #45362E;
}
    .jumbotron { 
    background-color: #EBBD63; /* Orange */
}
</style>

@endsection
