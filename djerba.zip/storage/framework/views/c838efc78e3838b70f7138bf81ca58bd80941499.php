<?php $__env->startSection('includes'); ?>
    <link href="<?php echo e(captcha_layout_stylesheet_url()); ?>" type="text/css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
            <?php if($id==0): ?>
                <div class="panel-heading">Offer Item for Sale</div>
            <?php elseif($id==1): ?>
                <div class="panel-heading">Speicial Order</div>
            <?php endif; ?>
                <div class="panel-body">
                <?php if($id==0): ?>
                    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('home/OfferItem/0/Submit')); ?>" autocomplete="nope" enctype="multipart/form-data">
                <?php else: ?>
                    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('home/SpecialOrder/1/Submit')); ?>" autocomplete="nope" enctype="multipart/form-data">
                <?php endif; ?>
                        <?php echo csrf_field(); ?>

                            <div class="form-group<?php echo e($errors->has('Item_Name') ? ' has-error' : ''); ?>">
                            <?php if($id==0): ?>
                                <label class="col-md-4 control-label">Item Name</label>
                            <?php else: ?>
                                <label class="col-md-4 control-label">Order Name</label>
                            <?php endif; ?>

                                <div class="col-md-6">
                                    <input type="text" maxlength="20" pattern="^[a-zA-Z0-9\s_]+$" title="An item name should contain letters, underscores, and numbers only."  class="form-control input-sm" name="Item_Name" value="<?php echo e(old('Item_Name')); ?>" placeholder="My_Item1">

                                    <?php if($errors->has('Item_Name')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('Item_Name')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                             <div class="form-group<?php echo e($errors->has('Height') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Height in cm </label>

                                <div class="col-md-3">
                                    <input type="text" pattern="^[0-9]{1,5}(\.[0-9]{1,2})?$"  maxlength="8" title="A height should contain a number only (with maximum value 99999.99)" class="form-control input-sm" name="Height" value="<?php echo e(old('Height')); ?>" placeholder="00000.00">

                                    <?php if($errors->has('Height')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('Height')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                            </div>
                            </div>



                            <div class="form-group<?php echo e($errors->has('Length') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Length in cm </label>

                                <div class="col-md-3">
                                    <input type="text" pattern="^[0-9]{1,5}(\.[0-9]{1,2})?$"  maxlength="8" title="A length should contain a number only (with maximum value 99999.99)" class="form-control input-sm" name="Length" value="<?php echo e(old('Length')); ?>" placeholder="00000.00">


                                    <?php if($errors->has('Length')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('Length')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                            </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('Width') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Width in cm </label>

                                <div class="col-md-3">
                                    <input type="text" pattern="^[0-9]{1,5}(\.[0-9]{1,2})?$"  maxlength="8" title="A width should contain a number only (with maximum value 99999.99)" class="form-control input-sm" name="Width" value="<?php echo e(old('Width')); ?>" placeholder="00000.00">

                                    <?php if($errors->has('Width')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('Width')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                            </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('Price') ? ' has-error' : ''); ?>">
                            <?php if($id==0): ?>
                                <label class="col-md-4 control-label">Price in L.E </label>
                            <?php else: ?>
                                <label class="col-md-4 control-label">Wished Price in L.E </label>
                            <?php endif; ?>
                                <div class="col-md-3">
                                    <input type="text" pattern="^[0-9]{1,5}$"  maxlength="8" title="A price should contain an integer number only (with maximum value 99999)" class="form-control input-sm" name="Price" value="<?php echo e(old('Price')); ?>" placeholder="00000" autocomplete="off">

                                    <?php if($errors->has('Price')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('Price')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                            </div>
                            </div>


                            <div class="form-group<?php echo e($errors->has('ArtSchools') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label">Art School</label>

                            <div class="col-md-6">
                              <select class="form-control input-sm" name="ArtSchools">
                              <?php foreach($artschools as $artschool): ?>
                                <option value= "<?php echo htmlspecialchars($artschool->id); ?>"><?php echo e($artschool->name); ?></option>
                              <?php endforeach; ?>
                              <?php if(count($artschools)==0): ?>
                                <option>There are no categories available.</option>
                              <?php endif; ?>
                              </select>

                              <?php if($errors->has('ArtSchools')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('ArtSchools')); ?></strong>
                                        </span>
                              <?php endif; ?>

                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('Colors') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label">Color Type</label>

                            <div class="col-md-6">
                              <select class="form-control input-sm" name="Colors">
                              <?php foreach($colors as $color): ?>
                                <option value= "<?php echo htmlspecialchars($color->id); ?>" ><?php echo e($color->name); ?></option>
                              <?php endforeach; ?>
                              <?php if(count($colors)==0): ?>
                                <option>There are no colors available.</option>
                              <?php endif; ?>
                              </select>

                              <?php if($errors->has('Colors')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('Colors')); ?></strong>
                                        </span>
                              <?php endif; ?>

                            </div>
                        </div>


                        <div class="form-group<?php echo e($errors->has('File') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label">Upload photo(s) -Up to 5 photos-</label>

                            <div class="col-md-6">
                                <input type="file" class="form-control input-sm" name="File" multiple>
                                <?php if($errors->has('File')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('File')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('Password') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label">Confirm Your Password</label>

                            <div class="col-md-6">
                                <input type="Password" class="form-control input-sm" name="Password" placeholder="Minimum is 6 characters" autocomplete="off">

                                <?php if($errors->has('Password')): ?>
                                    <span class="help-block">
                                        <strong>Wrong password. Try again please.</strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                            
                        <div class="row">
                            <label class="col-md-4 control-label">CAPTCHA Code</label>
                            <div class="col-md-6">
                                <?php echo captcha_image_html('LoginCaptcha'); ?>

                            </div>
                        </div>
                        <div class="row">&nbsp;</div>
                        <div class="form-group<?php echo e($errors->has('CaptchaCode') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label"></label>
                            <div class="col-md-6">
                                <input type="text" class="form-control input-sm" id="CaptchaCode" name="CaptchaCode" placeholder="What is the above CAPTCHA?">

                                 <?php if($errors->has('CaptchaCode')): ?>
                                    <span class="help-block">
                                        <strong>Wrong code. Try again please.</strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                  <i class="fa fa-btn fa-check" ></i></i>Submit
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>