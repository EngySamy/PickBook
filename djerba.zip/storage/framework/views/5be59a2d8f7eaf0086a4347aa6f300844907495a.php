<?php $__env->startSection('HomeisActive'); ?>
    class="active"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('includes'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container">

        <div style="text-align: right">
            
            <div class="btn-group" style="position: relative;">
                <a href="/home/0/index" class="btn btn-primary btn1">Sell</a>
                <a href="home/1/index" class="btn btn-primary btn2" >Special Order</a>
                
              </div>
               <script>
                $(document).ready(function(){
                    $('.btn1').tooltip({title: "Offer Item for Sale", animation: true,delay: 400,placement: "bottom"}); 
                });
                </script> 
              <script>
                $(document).ready(function(){
                    $('.btn2').tooltip({title: "Order Item with Special Specs", animation: true,delay: 400,placement: "bottom"}); 
                });
                </script> 

        </div>
        <div class="row">
            <div class="col-md-3">
                <p class="lead">Categories</p>
                <div class="list-group">
                    <?php foreach($artschools as $artschool): ?>
                    <a href="/home/artschool/<?php echo e($artschool->id); ?>" 
                    class="list-group-item <?php echo e(Request::is('home/artschool/'.$artschool->id) ? 'active' : ''); ?>"style="height: 40px;"><?php echo e($artschool->name); ?></a>
                    <?php endforeach; ?>
                    <?php if(count($artschools)==0): ?>
                        <p>There are no categories available.</p>
                    <?php endif; ?>
                </div>
                <p class="lead">Colors</p>
                <div class="list-group">
                    <?php foreach($colors as $color): ?>
                    <a href="/home/color/<?php echo e($color->id); ?>" class="list-group-item <?php echo e(Request::is('home/color/'.$color->id) ? 'active' : ''); ?>" style="height: 40px;"><?php echo e($color->name); ?></a>
                    <?php endforeach; ?>
                    <?php if(count($colors)==0): ?>
                        <p>There are no colors available.</p>
                    <?php endif; ?>
                </div>
                <div class="row">&nbsp;</div>
            </div>

            <div class="col-md-9">
                <?php if(!is_null($items)): ?>
                <p class="lead">Featured</p>
                <div class="row">
                    <?php foreach($items as $item): ?>
                    <a href="/<?php echo e($item->id); ?>/item">
                    <div class="col-sm-4 col-lg-4 co l-md-4">
                        <div class="thumbnail">
                            <?php foreach($item->images as $index=>$image): ?>
                                <?php if($index==0): ?>
                                     <img class="img-responsive center-block slide-image" src="<?php echo e(url($image->link)); ?>" style="width:auto; height:141px" alt=""/>
                                <?php endif; ?>
                            <?php endforeach; ?>
                            <div class="caption">
                                <h4 class="pull-right"><?php echo e($item->price); ?> LE</h4>
                                <h4><a href="/<?php echo e($item->id); ?>/item"><?php echo e($item->name); ?></a></h4>
                                <?php if($item->artSchool!=null): ?>
                                     <p>Category: <?php echo e($item->artSchool->name); ?></p>
                                <?php else: ?>
                                     <p>Category: None</p>
                                <?php endif; ?>
                                <?php if($item->colorType!=null): ?>
                                     <p>Colors: <?php echo e($item->colorType->name); ?></p>
                                <?php else: ?>
                                     <p>Colors: None</p>
                                <?php endif; ?>
                                <a href="/<?php echo e($item->id); ?>/item"><p class="pull-right"><?php echo e(($item->sold==false)?'Available':'Sold out'); ?></p></a>
                                <?php for($i=0;$i<$item->AverageRating()&&$i<5;$i++): ?>
                                    <span class="glyphicon glyphicon-star gold"></span>
                                <?php endfor; ?>
                                <?php for($i=0;$i<5-$item->AverageRating();$i++): ?>
                                    <span class="glyphicon glyphicon-star-empty gold"></span>
                                <?php endfor; ?> 
                            </div>
                        </div>
                    </div>
                    </a>
                    <?php endforeach; ?>            
                </div>
             <div class="text-center">
                    <?php echo $items->render(); ?>    <!--Display Dynamic Pagination at the bottom-->
             </div>
             <div class="row">&nbsp;</div>
              <?php endif; ?>
              <?php if($items->count()==0): ?>
                        <div class="well well-danger">
                            <h3 class="text-center">NOTHING FOUND</h3>
                            <div class="row text-center">&nbsp;</div>
                            <h5 class="text-muted text-center">There are no items to display.</h5>
                            <div class="row">&nbsp;</div>
                            <div class="row">&nbsp;</div>
                        </div>
              <?php endif; ?>     
        </div>

    </div>

    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>