<?php $__env->startSection('title'); ?>
- About US
<?php $__env->stopSection(); ?>

<?php $__env->startSection('AboutusisActive'); ?>
    class="active"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
   <img src="/assets/images/palette.jpg" alt="Palette Image" class="img-responsive center-block" style="width: 100%; display: block;"/>
</div>

<style>
    body{
    background-color: #45362E;
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>