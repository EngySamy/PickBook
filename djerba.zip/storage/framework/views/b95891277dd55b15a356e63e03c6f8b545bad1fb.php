<?php $__env->startSection('content'); ?>
<body>
  <div class="row">&nbsp;</div>
  <div class="row">&nbsp;</div>
  <div class="jumbotron text-center">
  <div class="container">
    <h1>DJERBA</h1> 
    <h4 style=" color: #87766C;">Your portal for art</h4> 
  </div>
  </div>
</body>

<style>
    body{
    background-color: #45362E;
}
    .jumbotron { 
    background-color: #EBBD63; /* Orange */
}
</style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>