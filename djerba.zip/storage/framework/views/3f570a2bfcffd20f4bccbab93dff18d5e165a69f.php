<?php $__env->startSection('title'); ?>
- Contact US
<?php $__env->stopSection(); ?>

<?php $__env->startSection('ContactusisActive'); ?>
    class="active"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
   
    <div class="row" style="overflow-x:auto;">
    
        <table class="table table-hover" style="table-layout: fixed;font-size:14px;" > 
            <col width="50">
            <col width="200">
            <thead>
            <?php if(count($complaints)!=0): ?>
                                
                            
                <tr>
                <td class="lead" >Customer ID</td>
                <td class="lead" >Complaint</td>
                </tr>
            <?php endif; ?>
                    <tbody >        
            
                    <?php foreach($complaints as $complaint): ?>
                        <tr>
                            <td onclick="getElementById('<?php echo e($complaint->id); ?>').click()" style="cursor: pointer;font-size: 14px;">
                                <?php echo e($complaint->customer_id); ?>

                             </td>
                        
                        
                            <td onclick="getElementById('<?php echo e($complaint->id); ?>').click()" href="#<?php echo e($complaint->id); ?>" class="list-group-item" data-toggle="collapse" style="cursor: pointer;font-size: 14px;">
                                         <?php echo e(str_limit($complaint->customer_text,5)); ?>

                        
                                <div id="<?php echo e($complaint->id); ?>" class="collapse">


                                   <i class="fa fa-share" aria-hidden="true"></i> <?php echo e($complaint->customer_text); ?>

                                </div>
                            
                            </td>
                            
                            
                            
                            
                        </tr>

                    <?php endforeach; ?>
                    </tbody>
                </thead>  
            </table>
                      <?php if(count($complaints)==0): ?>
                                <p>There are no complaints available.</p>
                            <?php endif; ?>
                                       
                                                          
        

    </div>
                       
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>