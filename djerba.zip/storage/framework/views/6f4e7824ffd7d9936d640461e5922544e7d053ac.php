<?php $__env->startSection('includes'); ?>
 <link href=<?php echo e(URL::asset('assets/item/css/shop-item.css')); ?> rel="stylesheet">
 <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
 <link rel="stylesheet" href=<?php echo e(URL::asset('assets/item/css/star-rating.css')); ?> media="all" rel="stylesheet" type="text/css"/>


 <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
 <script src=<?php echo e(URL::asset('assets/item/js/star-rating.js')); ?> type="text/javascript"></script>

 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
 <!-- Page Content -->
    <div class="container">

        <div class="row">

            <div class="col-md-7">
                <div class="well">
                <div class="row carousel-holder">
                    <div class="col-md-12">
                        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                            <ol class="carousel-indicators">
                                <?php for($i=0;$i<$images->count();$i++): ?>
                                  <li data-target="#carousel-example-generic" data-slide-to="<?php echo e($i); ?>" class="active"></li>
                                <?php endfor; ?>

                            </ol>
                            <div class="carousel-inner">
                                <?php foreach($images as $index=>$image): ?>
                                    <div class="item <?php if($index == 0): ?> <?php echo e('active'); ?> <?php endif; ?>">
                                        <a href="<?php echo e(url($image->link)); ?>"><img class="img-responsive center-block slide-image" style="height:360px; width:auto;" src="<?php echo e(url($image->link)); ?>" alt=""/></a>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
                                <span class="glyphicon glyphicon-chevron-left"></span>
                            </a>
                            <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
                                <span class="glyphicon glyphicon-chevron-right"></span>
                            </a>
                        </div>
                        </div>
                        </div>
                        <?php if(Auth::user()->role==1): ?>
                        <div class="form-group" style="padding-top: 30px; padding-bottom: 20px;">
                        
                                <?php if(!$item->sold): ?>
                              <h2 class="text-warning" style=" padding-bottom: 10px; text-align: center">AVAILABLE</h2>
                              <div class="span12" style="text-align: center">
                                

                                <!-- For Buy Request -->
                                <button type="button" class="btn btn-primary" id="order">
                                  <span class="glyphicon glyphicon-shopping-cart" style="padding-right: 10px;"></span>Order this item
                                </button>
                              </div> <!-- //////////////////////////////////////// -->
                                <!-- Modal -->
                                <div class="modal fade" id="confirm" role="dialog">
                                  <div class="modal-dialog">
                                  
                                    <!-- Modal content-->
                                    <div class="modal-content">
                                      <div class="modal-header" style="text-align:center;" >
                                        <button type="button" class="close" data-dismiss="modal">×</button>
                                        <h4 class="modal-title">Order " <?php echo e($item->name); ?> " Item</h4>
                                      </div>

                                      <div class="modal-body" >
                                        <br>
                                        <form action="/item/<?php echo e($id); ?>/Buy" method="POST">
                                        <div class="form-group">
                                          <label class="col-md-4 control-label">Confirm Your Password</label>

                                          <div class="col-md-7">
                                              <input type="Password" class="form-control input-sm" name="Password" placeholder="Minimum is 6 characters" autocomplete="off">
                                          </div>
                                      <br>
                                      <br>
                                        
                                      </div>
                                      <div class="modal-footer">
                                         
                                      <?php echo e(csrf_field()); ?>     
                                        <button type="submit" class="btn btn-primary">Confirm</button>
                                        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                                        
                                      </div>
                                      </form>
                                    </div>
                                    
                                  </div>
                                </div>

                                 <script>
                                $(document).ready(function(){
                                    $("#order").click(function(){
                                        $("#confirm").modal({backdrop: "static"});
                                    });
                                });
                                </script>

                                </div>

                                <?php else: ?>
                                   <h2 class="text-warning" style=" padding-bottom: 10px; text-align: center">SOLD OUT</h2>
                                   <h5 class="text-muted" style="text-align: center">Do you like this item? We will see what we can do for you!
                                   </h5>
                                   <div class="span12" style="text-align: center">
                                     <button type="submit" class="btn btn-primary">
                                            <span class="glyphicon glyphicon-shopping-cart" style="padding-right: 10px;"></span>Special order an item like this!
                                      </button>
                                    </div>
                                <?php endif; ?>
                                <div class="span12" style="padding-top: 50px;">
                                    <form action="<?php echo e($id); ?>/rate" method="POST" class="form-inline text-center" role="form">
                                          <?php echo csrf_field(); ?>

                                          <div class="form-group">
                                              <input id="input-21e" value="<?php echo e($rate); ?>" type="number" class="rating" min=0 max=5 step=1 data-size="xs" name="rateval" ></input>
                                          </div>
                                          <div class="form-group">
                                              <input type="submit" value="Rate" class="btn btn-primary pull-right"></input>
                                          </div>
                                    </form>
                                </div>
                                <?php if(Session::has('message')): ?>
                                      <div class="row">&nbsp;</div>
                                      <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('message')); ?></p>
                                <?php endif; ?>
                        </div>
                        <?php elseif(Auth::user()->role==2): ?>
                           <?php if(!$item->sold): ?>
                              <h2 class="text-warning" style=" padding-bottom: 10px; text-align: center">AVAILABLE</h2>
                            <?php else: ?>
                            <h2 class="text-warning" style=" padding-bottom: 10px; text-align: center">SOLD OUT</h2>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    </div>
                    
             <div class="col-md-5">

                   <div class="caption-full description well">
                        <h4 class="text-center"><a href="#"><?php echo e($item->name); ?></a></h4>
                        <ul>
                          <li style="padding-top: 20px;">
                            <h4><strong>Item No. </strong>
                            <h5 class="text-muted" style="padding-left: 25px"><?php echo e($item->id); ?></h5>
                            </h4>

                          <li style="padding-top: 20px;">
                            <h4><strong>Art Category </strong>
                            <?php if($item->artSchool!=null): ?>
                            <h5 class="text-muted" style="padding-left: 25px"><?php echo e($item->artSchool->name); ?></h5>
                            <?php else: ?>
                            <h5 class="text-muted" style="padding-left: 25px">None</h5>
                            <?php endif; ?>
                            </h4>
                            
                          </li>
                          <li style="padding-top: 20px;">
                            <h4> <strong>Type of colors </strong>
                            <?php if($item->colorType!=null): ?>
                            <h5 class="text-muted" style="padding-left: 25px"><?php echo e($item->colorType->name); ?></h5>
                            <?php else: ?>
                            <h5 class="text-muted" style="padding-left: 25px">None</h5>
                            <?php endif; ?>
                            </h4>     
                          </li>
                          <li style="padding-top: 20px;">
                              <h4><strong>Dimensions </strong>
                              <h5 class="text-muted" style="padding-left: 25px">Length: <?php echo e($item->length); ?> cm</h5>
                              <h5 class="text-muted" style="padding-left: 25px">Width: <?php echo e($item->width); ?> cm</h5>
                              <h5 class="text-muted" style="padding-left: 25px">Height: <?php echo e($item->height); ?> cm</h5>
                              </h4>
                          </li>
                          <li style="padding-top: 20px;">
                              <h4><strong>Offered by </strong>
                              <a href="/profile/<?php echo e($item->Customer->id); ?>" ><h5 class="text-muted" style="padding-left: 25px"><?php echo e($item->Customer->username); ?></h5></a>
                              </h4>
                          </li>
                          <li style="padding-top: 20px;">
                             <h4> <strong>Offered Price </strong>
                              <h5 class="text-muted" style="padding-left: 25px"><?php echo e($item->price); ?> LE</h5>
                             </h4>
                          </li>
                          <li style="padding-top: 20px;"> 
                          <h4><strong>Average Rating </strong>
                            <h5 style="padding-left: 25px">
                                <?php for($i=0;$i<$avg_rate&&$i<5;$i++): ?>
                                    <span class="glyphicon glyphicon-star gold"></span>
                                <?php endfor; ?>
                                <?php for($i=0;$i<5-$avg_rate;$i++): ?>
                                    <span class="glyphicon glyphicon-star-empty gold"></span>
                                <?php endfor; ?>
                            </h5>
                        </ul>
                    </div>
                </div>
        </div>
    </div>



    <script>
    jQuery(document).ready(function () {
        $("#input-21f").rating({
            starCaptions: function(val) {
                if (val < 3) {
                    return val;
                } else {
                    return 'high';
                }
            },
            starCaptionClasses: function(val) {
                if (val < 3) {
                    return 'label label-danger';
                } else {
                    return 'label label-success';
                }
            },
            hoverOnClear: false
        });
        
        $('#rating-input').rating({
              min: 0,
              max: 5,
              step: 1,
              size: 'lg',
              showClear: false
           });
           
        $('#btn-rating-input').on('click', function() {
            $('#rating-input').rating('refresh', {
                showClear:true, 
                disabled: !$('#rating-input').attr('disabled')
            });
        });
        
        
        $('.btn-danger').on('click', function() {
            $("#kartik").rating('destroy');
        });
        
        $('.btn-success').on('click', function() {
            $("#kartik").rating('create');
        });
        
        $('#rating-input').on('rating.change', function() {
            alert($('#rating-input').val());
        });
        
        
        $('.rb-rating').rating({'showCaption':true, 'stars':'3', 'min':'0', 'max':'3', 'step':'1', 'size':'xs', 'starCaptions': {0:'status:nix', 1:'status:wackelt', 2:'status:geht', 3:'status:laeuft'}});
    });
</script>


 


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>