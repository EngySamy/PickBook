<?php $__env->startSection('title'); ?>
- Contact US
<?php $__env->stopSection(); ?>

<?php $__env->startSection('ContactusisActive'); ?>
    class="active"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
   
    
        

    
    
<form id="contact_form" action="/contactus/submit1" method="post">
    <?php echo csrf_field(); ?>

                                      
     
    <div class="row" style="margin:0 auto;width:75%;text-align:center">
      <body style="text-align: center;">
        <label for="message" class="lead">Your Complaint</label><br />
        <textarea id="complaint" class="input" name="complaint" rows="7" cols="30"></textarea><br />
    </body>

    </div>
    
    <button id="complain_button" type="submit" class="btn btn-primary">Complain</button>
        </form>

    
<form id="contact_form" action="/contactus/submit2" method="post" >
    <?php echo csrf_field(); ?>

                                      
    
    <div class="row" style="margin:0 auto;width:75%;text-align:center" >
    <body style="text-align: center;">
        <label for="message" class="lead">Your Suggestion</label><br />
        <textarea id="suggestion" class="input" name="suggestion" rows="7" cols="30" ></textarea><br />
    </body>
    </div>
    <button id="suggest_button" type="submit" class="btn btn-primary" >Suggest</button>

</form>                     
               
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>