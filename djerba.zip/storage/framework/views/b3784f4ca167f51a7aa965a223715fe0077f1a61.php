<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading"> <?php echo e($user->username); ?> Items </div>

                <div class="panel-body">
                    <div class="row">

                    <?php foreach($items as $item): ?>
                    <a href="/item/<?php echo e($item->id); ?>">
                    <div class="col-sm-4 col-lg-4 co l-md-4">
                         <div class="thumbnail">
                           <?php foreach($item->images as $index=>$image): ?>
                                <?php if($index==0): ?>
                                     <img class="img-responsive center-block slide-image" src="<?php echo e(url($image->link)); ?>" style="width:auto; height:141px" alt=""/>
                                <?php endif; ?> 
                            <?php endforeach; ?> 
                               <div class="caption">
                                <h4 class="pull-right"><?php echo e($item->price); ?> LE</h4>
                                <h4><a href="/item/<?php echo e($item->id); ?>"><?php echo e($item->name); ?></a></h4>
                                <?php if($item->artSchool!=null): ?>
                                     <p>Category: <?php echo e($item->artSchool->name); ?></p>
                                <?php else: ?>
                                     <p>Category: None</p>
                                <?php endif; ?>
                                <?php if($item->colorType!=null): ?>
                                     <p>Colors: <?php echo e($item->colorType->name); ?></p>
                                <?php else: ?>
                                     <p>Colors: None</p>
                                <?php endif; ?>
                                <a href="/item/<?php echo e($item->id); ?>"><p class="pull-right"><?php echo e(($item->sold==false)?'Available':'Sold out'); ?></p></a>
                                <?php for($i=0;$i<$item->AverageRating()&&$i<5;$i++): ?>
                                    <span class="glyphicon glyphicon-star gold"></span>
                                <?php endfor; ?>
                                <?php for($i=0;$i<5-$item->AverageRating();$i++): ?>
                                    <span class="glyphicon glyphicon-star-empty gold"></span>
                                <?php endfor; ?> 
                            </div>
                        </div>
                    </div>
                    </a>
                    <?php endforeach; ?> 
                    <?php if(count($items)==0): ?>
                        <div class="text-center">
                            <p>There are no items available.</p>
                            </div>
                    <?php endif; ?>           
                </div>
                 <!--Display Dynamic Pagination at the bottom-->
                   <div class="text-center">
                        <?php echo $items->render(); ?>   
                    </div> 
                </div>

            </div>
        </div>
    </div>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>