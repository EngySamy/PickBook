<?php $__env->startSection('addrequests'); ?>
      <div class="col-md-9">
          <div class="panel-body">
             <?php if($Requests->count()==0): ?>
                  <div class="well well-danger" style="height: 350px; padding-top: 80px; margin-top: 65px;" >
                        <h3 class="text-center">NOTHING FOUND</h3>
                        <div class="row text-center">&nbsp;</div>
                      <?php if($id==0): ?>
                        <h5 class="text-muted text-center">There are no sell requests to display.</h5>
                      <?php else: ?>
                        <h5 class="text-muted text-center">There are no special orders to display.</h5>
                      <?php endif; ?>
                        <div class="row">&nbsp;</div>
                        <div class="row">&nbsp;</div>
                    </div>
              <?php else: ?>
              <table class="table table-hover" >
              <thead>
                <td>Item Name</td>
                <td>Assigned QS</td>

                <?php if($id==0): ?> 
                <td>Seller Username</td>
                <?php else: ?> 
                <td>Requester Username</td>
                <?php endif; ?>

              </thead>
              <tbody style="color: #555555; border-bottom:1px solid #dddddd">
              <?php foreach($Requests as $Request): ?>
                <tr onclick="getElementById('<?php echo e($Request->id); ?>').click()" style="cursor: pointer">
                  <td>
                
                  <a href="/<?php echo e($id); ?>/<?php echo e($Request->id); ?>/detail" id="<?php echo e($Request->id); ?>" style="color: inherit; font-size: 14px;">
               
                  <?php echo e(str_limit($Request->name,10)); ?></a></td>
                  <?php if(is_null($Request->QS)): ?>
                  <td>none</td>
                  <?php else: ?>
                  <td><?php echo e($Request->QS->name); ?></td> 
                  <?php endif; ?>
                  <td><?php echo e($Request->Customer->username); ?></td> 
                </tr>  
                <?php endforeach; ?> 
              </tbody>
            </table>  
            <?php endif; ?>
        </div>
        
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.QS', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>