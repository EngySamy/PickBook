<?php $__env->startSection('RegisterisActive'); ?>
    class="active"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('includes'); ?>
    <link href="<?php echo e(captcha_layout_stylesheet_url()); ?>" type="text/css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <?php echo $__env->yieldContent('CategoriesAndColors'); ?>
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Register</div>
                <div class="panel-body">
                    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/register')); ?>">
                        <?php echo csrf_field(); ?>

                            <div class="form-group<?php echo e($errors->has('First_Name') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">First Name</label>

                                <div class="col-md-6">
                                    <input type="text" maxlength="20" pattern="^[a-zA-Z]+$" title="A name should contain letters only." class="form-control input-sm" name="First_Name" value="<?php echo e(old('First_Name')); ?>" placeholder="John">

                                    <?php if($errors->has('First_Name')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('First_Name')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                             <div class="form-group<?php echo e($errors->has('Last_Name') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Last Name</label>

                                <div class="col-md-6">
                                    <input type="text" maxlength="20" pattern="^[a-zA-Z]+$" title="A name should contain letters only." class="form-control input-sm" name="Last_Name" value="<?php echo e(old('Last_Name')); ?>" placeholder="Smith">

                                    <?php if($errors->has('Last_Name')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('Last_Name')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                            </div>
                        </div>


                        <div class="form-group<?php echo e($errors->has('Email') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label">E-Mail Address</label>

                            <div class="col-md-6">
                                <input type="Email" class="form-control input-sm" name="Email" value="<?php echo e(old('Email')); ?>" placeholder="example@example.com">

                                <?php if($errors->has('Email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('Email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('Email_confirmation') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label">Confirm E-Mail Address</label>

                            <div class="col-md-6">
                                <input type="Email" class="form-control input-sm" name="Email_confirmation" placeholder="example@example.com">

                                <?php if($errors->has('Email_confirmation')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('Email_confirmation')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('Password') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label">Password</label>

                            <div class="col-md-6">
                                <input type="Password" class="form-control input-sm" name="Password" placeholder="Minimum is 6 characters">

                                <?php if($errors->has('Password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('Password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('Password_confirmation') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label" >Confirm Password</label>

                            <div class="col-md-6">
                                <input type="Password" class="form-control input-sm" name="Password_confirmation" placeholder="Must match the above password">

                                <?php if($errors->has('Password_confirmation')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('Password_confirmation')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('Phone') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label">Phone No.</label>

                            <div class="col-md-6">
                                <input type="text" pattern="^[0-9]+$" maxlength="11" title="A phone no. should contain numbers only" class="form-control input-sm" name="Phone" value="<?php echo e(old('Phone')); ?>" placeholder="Should be the main phone no.">

                                <?php if($errors->has('Phone')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('Phone')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('Address') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label">Home Address</label>

                            <div class="col-md-6">
                                <input type="text" pattern="^[a-zA-Z0-9\s,]+$" title="An address should contain letters, commas, and numbers only." class="form-control input-sm" name="Address" value="<?php echo e(old('Address')); ?>" placeholder="100 Example Street, City">

                                <?php if($errors->has('Address')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('Address')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                            
                        <div class="row">
                            <label class="col-md-4 control-label">CAPTCHA Code</label>
                            <div class="col-md-6">
                                <?php echo captcha_image_html('LoginCaptcha'); ?>

                            </div>
                        </div>
                        <div class="row">&nbsp;</div>
                        <div class="form-group<?php echo e($errors->has('CaptchaCode') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label"></label>
                            <div class="col-md-6">
                                <input type="text" class="form-control input-sm" id="CaptchaCode" name="CaptchaCode" placeholder="What is the above CAPTCHA?">

                                 <?php if($errors->has('CaptchaCode')): ?>
                                    <span class="help-block">
                                        <strong>Wrong code. Try again please.</strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fa fa-btn fa-user"></i>Register
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>