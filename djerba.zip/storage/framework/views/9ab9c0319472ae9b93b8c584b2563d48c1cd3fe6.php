<?php $__env->startSection('includes'); ?>
 <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<style>
.body1 {
   
    text-align: center;
    }
    li.buy
    {
        list-style-type: none;
        padding: 3px;
        padding-left: 35px;
    }
.list-group-item:hover,
.list-group-item:focus {
  background-color: #f5f5f5;
}
</style>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<body>
<div class="container">    
    <div class="row">
      <div class="col-md-3">
        <p class="lead">Go to</p>
            <div class="list-group">
                <a href="/0/show/SS" class="list-group-item <?php echo e(Request::is('0/show/SS') ? 'active' : ''); ?>" style="height: 40px;">Sell Requests</a>
                <a href="/2/show/BS" class="list-group-item <?php echo e(Request::is('2/show/BS') ? 'active' : ''); ?>" style="height: 40px;">Buy Requests</a>
                <a href="/1/show/SS" class="list-group-item <?php echo e(Request::is('1/show/SS') ? 'active' : ''); ?>" style="height: 40px;">New Special Orders</a>
                <a href="/3/show/BS" class="list-group-item <?php echo e(Request::is('3/show/BS') ? 'active' : ''); ?>"style="height: 40px;">Similar Special Orders</a>
     
            </div>

      </div>

      <?php echo $__env->yieldContent('addrequests'); ?>
     
       
  </div>

</body>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>