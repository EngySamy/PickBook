<?php $__env->startSection('title'); ?>
- Contact US
<?php $__env->stopSection(); ?>

<?php $__env->startSection('ContactusisActive'); ?>
    class="active"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
   
    <div class="row">
        <table class="table table-hover" style="table-layout: fixed;font-size:14px;"> 
            
<col width="50">
  <col width="200">
            <thead>
            <?php if(count($suggestions)!=0): ?>
                <tr>
                <td class="lead">Customer ID</td>
                <td class="lead">Suggestion</td>
                </tr>
            <?php endif; ?>
                    <tbody >        
            
                    <?php foreach($suggestions as $suggestion): ?>
                        <tr>
                            <td onclick="getElementById('<?php echo e($suggestion->id); ?>').click()" style="cursor: pointer;font-size: 14px">
                                <?php echo e($suggestion->customer_id); ?>

                             </td>
                        
                        
                            <td onclick="getElementById('<?php echo e($suggestion->id); ?>').click()" style="cursor: pointer" href="#<?php echo e($suggestion->id); ?>" class="list-group-item" data-toggle="collapse">
                                         <?php echo e(str_limit($suggestion->text,5)); ?>

                        
                                <div id="<?php echo e($suggestion->id); ?>" class="collapse" style="font-size: 14px">


                                    <i class="fa fa-share" aria-hidden="true"></i> <?php echo e($suggestion->text); ?>

                                </div>
                            
                            </td>
                    
                            
                            
                        </tr>

                    <?php endforeach; ?>
                    </tbody>
                </thead>  
            </table>
                            <?php if(count($suggestions)==0): ?>
                                <p>There are no suggestions available.</p>
                            <?php endif; ?>
                                       
                                                          
        

    </div>
                       
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>