<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Djerba <?php echo $__env->yieldContent('title'); ?></title>

    <!-- Fonts -->
    <link rel="stylesheet" href="/assets/font-awesome-4.6.3/css/font-awesome.min.css">

    <link rel="stylesheet" href="/assets/css/fonts/google-lato.css">

    <!-- Styles -->
    <link rel="stylesheet" href="/assets/css/bootstrap.min.original.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
    <?php /* <link href="<?php echo e(elixir('css/app.css')); ?>" rel="stylesheet"> */ ?>

    <link rel="stylesheet" href="/assets/css/bootstrap.min.css"/>

    <link href="/assets/css/flat-ui.css" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

    <?php echo $__env->yieldContent('includes'); ?>

	<style>
        body {
            font-family: 'Lato';
        }

        .fa-btn {
            margin-right: 6px;
        }
    </style>
  
</head>
<body id="app-layout">

    <nav class="navbar navbar-inverse navbar-embrossed navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#app-navbar-collapse">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span> 
                    </button>
                                <!-- Branding Image -->
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    Djerba
                </a>
            </div>

            <div class="collapse navbar-collapse" id="app-navbar-collapse">
                <!-- Left Side Of Navbar -->
                <ul class="nav navbar-nav">
                    <li <?php echo $__env->yieldContent('HomeisActive'); ?>><a href="<?php echo e(url('/home')); ?>"><?php echo e(htmlentities('Art & Antiques')); ?></a></li>
                    <li <?php echo $__env->yieldContent('AboutusisActive'); ?>><a href="<?php echo e(url('/aboutus')); ?>">About US</a></li>
                    <li <?php echo $__env->yieldContent('ContactusisActive'); ?>><a href="<?php echo e(url('/contactus')); ?>">Contact US</a></li>
                </ul>

                <!-- Right Side Of Navbar -->
                <ul class="nav navbar-nav navbar-right">
                    <!-- Authentication Links -->
                    <?php if(Auth::guest()): ?>
                        <li <?php echo $__env->yieldContent('LoginisActive'); ?>><a href="<?php echo e(url('/login')); ?>">Login</a></li>
                        <li <?php echo $__env->yieldContent('RegisterisActive'); ?>><a href="<?php echo e(url('/register')); ?>">Register</a></li>
                   <?php else: ?>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                            </a>

                            <ul class="dropdown-menu" role="menu">
                                <?php if(Auth::user()->role==1): ?>
                                <li><a href="<?php echo e(url('/myprofile')); ?>" style="font-size: 14px;"><i class="fa fa-btn fa-user"></i>My Profile</a></li>
                                <li><a href="<?php echo e(url('/0/inbox')); ?>" style="font-size: 14px;"><i class="fa fa-btn fa-inbox"></i>Inbox</a></li>
                                <?php endif; ?>

                                <?php if(Auth::user()->role==2): ?>
                                <li><a href="<?php echo e(url('/QShome')); ?>" style="font-size: 14px;"><i class="fa fa-btn fa-bars"></i>QS panel</a></li>
                                <?php endif; ?>
                                <?php if(Auth::user()->role==3): ?>
                                <li><a href="<?php echo e(url('/HRPanel')); ?>" style="font-size: 14px;"><i class="fa fa-btn fa-bars"></i>HR panel</a></li>
                                <?php endif; ?>
                                <li><a href="<?php echo e(url('/logout')); ?>" style="font-size: 14px;"><i class="fa fa-btn fa-sign-out"></i>Logout</a></li>

                            </ul>
                        </li>
                       
                    <?php endif; ?>
                    <li>
                         <form id="tfnewsearch" method="get" action="/search">
                               <input type="text" id="tfq" class="tftextinput2" name="keyword" size="18" maxlength="120" placeholder="Search.."><input type="submit" value="Go" class="tfbutton2">
                         </form>  
                    </li> 

                </ul>
            </div>
        </div>
    </nav>

    <?php echo $__env->yieldContent('content'); ?>

    
    <!-- JavaScripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.3/jquery.min.js" integrity="sha384-I6F5OKECLVtK/BL+8iSLDEHowSAfUo76ZL9+kGAgTRdiByINKJaqTPH/QVNS1VDb" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
    <?php /* <script src="<?php echo e(elixir('js/app.js')); ?>"></script> */ ?>
    
    <footer class="navbar-inverse navbar-fixed-bottom">
          <div class="container-fluid">
            <p class="text-center" style="color:#FFFFFF; font-size:12px;">&copy2016 Delta Systems. All rights reserved.</p>
          </div>
    </footer>

</body>
    <style>
        .gold {
            color: #D4AF37;
        }
        body { padding-top: 80px; padding-bottom: 70px; }
    </style>
</html>

<?php echo $__env->make('layouts.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>