<?php $__env->startSection('title'); ?>
- Contact US
<?php $__env->stopSection(); ?>

<?php $__env->startSection('ContactusisActive'); ?>
    class="active"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Contact US</div>

                
                    <div class="panel-body">
                        <div class="form-group">
                            <label class="col-md-2 control-label" style="font-size: 14px">Your complaint :</label>
                                <form method="post" action="/contactus/complaints/submit">
                                        <?php echo csrf_field(); ?>

                                              <ul class="nav navbar-nav"> <li> <input class="form-control" type="text" maxlength="2000" pattern="^[a-zA-Z0-9\s,]+$" title="user_complaint" name="user_complaint" value="" placeholder="Your complaint" style="padding: 15px;font-size: 14px"></li>
                                            
                                        
                                    
                                        
                                            
                                                <li><button type="submit" class="btn btn-primary">
                                                    
                                                
                                                    <i class="fa fa-btn fa-user"></i>Submit
                                                    
                                                 </button></li>
                                            
                                        </ul>
                                </form>
                                    
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    
                                    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>