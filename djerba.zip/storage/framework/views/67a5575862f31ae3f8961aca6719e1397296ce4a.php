<?php $__env->startSection('title'); ?>
- Contact US
<?php $__env->stopSection(); ?>

<?php $__env->startSection('ContactusisActive'); ?>
    class="active"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
   
    <div class="row">

        <div class="col-md-10 col-md-offset-1">

            <div class="panel panel-default">
                <div class="panel-heading">Contact US</div>

                         <div class="panel-body">
                            
                            
                         Complaints and suggestions for improvements are placed here.                  
                         
                         </div>                            
            </div>  
                    <div class="panel panel-default">
                            <div class="panel-heading">Contact US</div>

                                 
                            
                                        <?php foreach($complaints as $complaint): ?>
                                             <div class="panel-body">   
                                             <?php echo e($complaint->customer_text); ?>


                                            </div>


                                                <?php endforeach; ?>
                                                <?php if(count($complaints)==0): ?>
                                                    <p>There are no complains available.</p>
                                        <?php endif; ?>
                                         
                         
                                                             
                    </div>                         
        </div>

    </div>
                       
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>