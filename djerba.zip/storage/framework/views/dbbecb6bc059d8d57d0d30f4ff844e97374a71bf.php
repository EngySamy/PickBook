<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-sm-3 col-md-2">
            
        </div>
        <div class="col-sm-9 col-md-10">
            <!-- Split button -->
            
            <button type="button" class="btn btn-default" data-toggle="tooltip" title="Refresh">
                &nbsp;&nbsp;&nbsp;<span class="glyphicon glyphicon-refresh"></span>&nbsp;&nbsp;&nbsp;</button>
            <!-- Single button -->
            <div class="btn-group">
                <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                    More <span class="caret"></span>
                </button>
                <ul class="dropdown-menu" role="menu">
                    <li><a href="#">Mark all as read</a></li>
                    <li class="divider"></li>
                    <li class="text-center"><small class="text-muted">Select messages to see more actions</small></li>
                </ul>
            </div>
            <div class="pull-right">
                <span class="text-muted"><b>1</b>–<b>50</b> of <b>160</b></span>
                <div class="btn-group btn-group-sm">
                    <button type="button" class="btn btn-default">
                        <span class="glyphicon glyphicon-chevron-left"></span>
                    </button>
                    <button type="button" class="btn btn-default">
                        <span class="glyphicon glyphicon-chevron-right"></span>
                    </button>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <div class="row">
        <div class="col-sm-3 col-md-2">
            <ul class="nav nav-pills nav-stacked">
                <li class="active"><a href="#"><span class="badge pull-right" style="margin:5px">32</span> Inbox </a>
                </li>
            </ul>
        </div>
        <div class="col-sm-9 col-md-10">
             
          <div class="list-group" id="accordion">
              <a href="#msg" class="list-group-item" data-parent="#accordion">
                  
                  <span class="name" style="min-width: 120px;display: inline-block;">Mark Otto</span> <span class="">Nice work on the lastest version</span>
                  <span class="text-muted" style="font-size: 11px;">....</span> <span class="badge" style="margin:4px;">12:10 AM</span> <span class="pull-right"><span class="glyphicon glyphicon-paperclip">
                      </span></span></a>
                     

                      
                  
                  


            </div>
          </div>
          
                
            
            
       
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>