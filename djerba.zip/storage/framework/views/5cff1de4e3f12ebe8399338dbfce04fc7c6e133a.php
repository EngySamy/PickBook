<?php $__env->startSection('addrequests'); ?>

      <div class="col-md-9">
          <div class="panel-body">
             <?php if($Requests->count()==0): ?>
                  <div class="well well-danger" style="height: 350px; padding-top: 80px; margin-top: 65px;" >
                        <h3 class="text-center">NOTHING FOUND</h3>
                        <div class="row text-center">&nbsp;</div>
                        <h5 class="text-muted text-center">There are no buy requests to display.</h5>
                        <div class="row">&nbsp;</div>
                        <div class="row">&nbsp;</div>
                    </div>
              <?php else: ?>

              <div class="list-group"  id="accordion" style="cursor: default; ">
                  <div class="list-group-item" style="color:#6F532A; border-top:0;border-left:0; border-radius:0;border-right:0; background-color:transparent;  ">Item Name</div>
                    <?php foreach($Requests as $Request): ?>
                    <a class="list-group-item" href="#<?php echo e($Request->id); ?>" data-parent="#accordion" data-toggle="collapse" style="font-size: 14px; color: #555555;border-left:0; border-radius:0;border-right:0; "><?php echo e($Request->Item->name); ?></a>  
                      <div id="<?php echo e($Request->id); ?>" class="collapse">
                      <?php if($Request->qs_id==NULL): ?>                   
                        <li class="buy"><a  tabindex="-1" href="/BuyRequests/<?php echo e($Request->id); ?>/serve" style="font-size: 14px;">Serve</a></li>
                      <?php elseif($Request->qs_id==$qs): ?>
                        <li class="buy"><a  tabindex="-1" href="/BuyRequests/<?php echo e($Request->buyer_id); ?>/customer" style="font-size: 14px;">Buyer Info</a></li>
                        <li class="buy"><a  tabindex="-1" href="/BuyRequests/<?php echo e($Request->Item->seller_id); ?>/customer" style="font-size: 14px;">Seller Info</a></li>
                        <li class="buy"><a  tabindex="-1" href="/BuyRequests/<?php echo e($Request->Item->id); ?>/item" style="font-size: 14px;">The Item on the website</a></li> 
                        <li class="buy"><a  tabindex="-1" href="#" style="font-size: 14px;" id="archive">Archive</a></li> 

                        <!-- Archive Modal -->
                        <div class="modal fade" id="archivemodal" role="dialog">
                          <div class="modal-dialog">
                          
                            <!-- Modal content-->
                            <div class="modal-content">
                              <div class="modal-header" style="text-align: center;">
                                <button type="button" class="close" data-dismiss="modal">×</button>
                                <h4 class="modal-title">Archive " <?php echo e($Request->Item->name); ?> " buy request</h4>
                              </div>

                              <div class="modal-body" >
                                <br>
                                <form action="/BuyRequests/<?php echo e($Request->id); ?>/archive" method="POST">
                                <div class="form-group">
                                  <label class="col-md-4 control-label" style="text-align: right;">Confirm Your Password</label>
                                  <div class="col-md-7">
                                      <input type="Password" class="form-control input-sm" name="Password" placeholder="Minimum is 6 characters" autocomplete="off">
                                  </div>
                                  <br>
                                  <br>
                                
                              </div>
                              <div class="modal-footer">
                                 
                                  <?php echo e(csrf_field()); ?>     
                                  <button type="submit" class="btn btn-primary">Confirm</button>
                                  <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                                
                               </div>
                              </form>
                            </div>
                            
                          </div>
                        </div>

                        <script>
                        $(document).ready(function(){
                            $("#archive").click(function(){
                                $("#archivemodal").modal({backdrop: "static"});
                            });
                        });
                        </script>

                        </div>

                        <!--  -->

                      <?php else: ?>                     
                        <li style="font-size: 14px; color: #606d7a; padding-right: 15px;">The request is assigned to another QS</li>
                      <?php endif; ?> 
                      </div> 
                  
                <?php endforeach; ?> 
                </div>
                

                
                
            <?php endif; ?>
        </div>
        
        </div>


      
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.QS', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>