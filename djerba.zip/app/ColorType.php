<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ColorType extends Model
{
    //
    //protected $fillable = ['name']; //this is required for insertion in tinker!
}
