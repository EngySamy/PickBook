<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ArtSchool extends Model
{
    //protected $fillable = ['name']; //this is required for insertion in tinker
}
